#include "mbed.h"

// HEADER U5:
       // SPI: MOSI MISO SCLK
       SPI spi(p5, p6, p7);
       DigitalOut cs(p10);  // its necessary to keep it low during data transfer

       DigitalOut io_reset(p9); // its necessary to keep it low during data transfer
       DigitalOut osk(p11);

// HEADER U6:
       DigitalOut io_update(p17);  // depends os the 23 bit of CFR2
       DigitalOut prof0(p18);
       DigitalOut prof1(p19);
       DigitalOut prof2(p20);

// HEADER U9:
       DigitalOut MASTER_RESET(p15);
       DigitalOut EXT_PWR_DWN(p14);


// MBED CONTROL AND FLAG PINS
       DigitalIn ctrl(p30);

       DigitalOut myled(LED1);
       DigitalOut myled2(LED2);

int main(){
       
       //  INITIALIZING PINS
              cs = 0;        
              io_reset = 0;
              io_update = 0;
              prof0 = 0;
              prof1 = 0;
              prof2 = 0;
              osk = 0;
    
       // INITIAL RESET
              EXT_PWR_DWN = 0;
              MASTER_RESET = 1;
              wait(2);
              MASTER_RESET = 0;        
              wait(1);
        
       //  SPI CONFIGURATION
              spi.format(8,0);
              spi.frequency(25000000);
        
       // CFR1 CONFIGURATION
              spi.write(0x00);           //  address
                     spi.write(0x00);    //  MSB
                     spi.write(0x00);
                     spi.write(0x00);
                     spi.write(0x02);    //  LSB
        
                     //  I/O UPDATE PULSE
                     io_update = 1;
                     wait_us(100);
                     io_update = 0;
        
       // CFR2 CONFIGURATION
              spi.write(0x01);           //  address
                     spi.write(0x00);    //  MSB
                     spi.write(0x40);
                     spi.write(0x08);
                     spi.write(0x00);    //  LSB
    
                     //  I/O UPDATE PULSE
                     io_update = 1;
                     wait_us(100);
                     io_update = 0;
        
       // CFR3 CONFIGURATION
              spi.write(0x02);           //  address
                     spi.write(0x17);    //  MSB
                     spi.write(0x38);
                     spi.write(0xC0);
                     spi.write(0x00);    //  LSB
    
                     //  I/O UPDATE PULSE
                     io_update = 1;
                     wait_us(100);
                     io_update = 0;
        
       //  Profile 0 (fout = 5 MHz)
               spi.write(0x0E);           //  address
                     spi.write(0x3F);    //  MSB     ASF - MSB
                     spi.write(0xFF);    //          ASF - LSB
                     spi.write(0x00);    //          POW - MSB
                     spi.write(0x00);    //          POW - LSB
                     spi.write(0x33);    //          FTW - MSB
                     spi.write(0x33);    //          FTW - LSB
                     spi.write(0x33);    //          FTW - MSB
                     spi.write(0x33);    //  LSB     FTW - LSB
            
                     //  I/O UPDATE PULSE
                     io_update = 1;
                     wait_us(100);
                     io_update = 0;
  
       //  Profile 01 (fout = 5 MHz + 1 Hz)
              spi.write(0x0F);           //  address
                     spi.write(0x3F);    //  MSB     ASF - MSB
                     spi.write(0xFF);    //          ASF - LSB
                     spi.write(0x00);    //          POW - MSB
                     spi.write(0x00);    //          POW - LSB
                     spi.write(0x33);    //          FTW - MSB
                     spi.write(0x33);    //          FTW - LSB
                     spi.write(0x33);    //          FTW - MSB
                     spi.write(0xDF);    //  LSB     FTW - LSB
            
                     //  I/O UPDATE PULSE
                     io_update = 1;
                     wait_us(100);
                     io_update = 0;
                
       //  Profile 02 (fout = 5 MHz + 1 Hz + 1 bit)
              spi.write(0x10);            //  address
                     spi.write(0x3F);     //  MSB     ASF - MSB
                     spi.write(0xFF);     //          ASF - LSB
                     spi.write(0x00);     //          POW - MSB
                     spi.write(0x00);     //          POW - LSB
                     spi.write(0x33);     //          FTW - MSB
                     spi.write(0x33);     //          FTW - LSB
                     spi.write(0x33);     //          FTW - MSB
                     spi.write(0xE0);     //  LSB     FTW - LSB
            
                     //  I/O UPDATE
                     io_update = 1;
                     wait_us(100);
                     io_update = 0;
                
       //  PROFILE UPDATE + BLINKY
                
              // INITIAL BLINKY  
                     myled = 1;
                     myled2 = 1;                
                            wait(0.5);
                     myled = 0;
                     myled2 = 0;
                                
              // UPDATE PROFILE LOOP
              while(1){                                        
                    if(ctrl == 0){
                            // PROFILE 01
                            prof0 = 1;
                            prof1 = 0;
                            prof2 = 0;

                            // LED FLAGS
                            myled = 1;
                            myled2 = 0;
                           
                            //  I/O UPDATE PULSE
                            io_update = 1;
                            wait_us(100);
                            io_update = 0;
                        
                            wait_us(100);
                             
                     }else{
                            // PROFILE 02
                            prof0 = 0;
                            prof1 = 1;
                            prof2 = 0;

                            // LED FLAGS
                            myled = 0;
                            myled2 = 1;
                           
                            //  I/O UPDATE PULSE
                            io_update = 1;
                            wait_us(100);
                            io_update = 0;

                            wait_us(100);
                     }                   
              }            
}
