#include "AD9910.h"

//  amp is normalized (between 0 and 1) - amplitude scale
//  phase is in degree

// write single tone register from amplitude, phase and frequency
void STP_write (int address, float amp,float phase,float fout,float fsysclk){
        
        uint64_t register_value = STP_get_reg(amp, phase, fout, fsysclk);
        printf("\tWriting at Single Tone Register...\n");
        write_register(address, register_value,64);
}

// returns the register to be used at the single tone profile's registers (AD9910)
    uint64_t STP_get_reg(float amp,float phase,float fout,float fsysclk){
        
        uint64_t reg, aux;
        long double aux_float;
        
        reg = 0x00;
        
        // calculating ASF
        aux_float = amp*pow(2.0,14.0);
        aux = fround(aux_float);
        
        printf("\n\t\tASF register: 0x%0X\n", aux);
        
        // concatenating ASF to final register
        aux<<=48;
        reg = reg|aux;        
        
        printf("\n\t\tPartial register: 0x%" PRIX64 "\n", reg);
        
        // calculating POW    
        aux_float = phase*pow(2.0,16.0)/360;
        aux = fround(aux_float);
        
        printf("\n\t\tPOW register: 0x%0X\n", aux);
        
        // concatenating POW to final register
        aux<<=32;
        reg = reg|aux;

        printf("\n\t\tPartial register: 0x%" PRIX64 "\n", reg);
            
        // calculating FTW    
        aux_float = ((double) fout/fsysclk)*(pow(2.0,32.0));
        aux = fround(aux_float);
        
        printf("\n\t\tFTW register: 0x%0X\n", aux);
        
        // concatenating FTW to final register
        reg = reg|aux;
        
        printf("\n\t\tFinal Register: 0x%" PRIX64 "\n", reg);
        
        return reg;   
    }

// returns number's nearest integer
    uint64_t fround(double nfloat){
        
        uint64_t nint;

        if( -(nfloat - (double)ceil(nfloat)) < (nfloat - (double)floor(nfloat))){
            nint = (uint64_t) ceil(nfloat);
        }
        else{
            nint = (uint64_t) floor(nfloat);
        }
        
        return nint;    
    }

// returns an array with the register's bytes separated (MSB)
    uint64_t *get_byte(uint64_t data, int data_size){
        
        int number_of_bytes;                      
        int i = 0;
        
        number_of_bytes = (int)fround(data_size/8);
        uint64_t filter = 0xFF*pow(2.0,8.0*(number_of_bytes-1));
        
        printf("\n\t\t\t---get_byte: Number of bytes: %d\n\n", number_of_bytes);
        
        uint64_t *bytes_array = (uint64_t*)malloc(sizeof(uint64_t)*number_of_bytes);
        
        while(i < number_of_bytes){
            
            printf("\t\t\t\tfilter: %016" PRIX64 "\n",filter);
            
            bytes_array[i] = (data & filter)>>((number_of_bytes-i-1)*8);
            
            printf("\t\t\t\t Byte %d: %02X\n", i, bytes_array[i]);
            
            filter>>= 8;
            
            i++;
        }
        
    return bytes_array;        
        
}
    
void update_profile(int p0, int p1, int p2){
    
    /*DigitalOut  prof0(p16);
    DigitalOut  prof1(p17);
    DigitalOut  prof2(p19);
    
    prof0 = p0;
    prof1 = p1;
    prof2 = p2;*/
    
}

// reset the AD9910 board
void reset_board(){
    
    int MASTER_RESET;
    int EXT_PWR_DWN;
    
    EXT_PWR_DWN = 0;
    MASTER_RESET = 1;
    printf("\t\t---reset_board(): 2 seconds pulse\n\n");
    MASTER_RESET = 0;
        
    //wait(1);    
}

// initialize pins
void initialize_pins(){
        
        int cs;         // its necessary to keep it low during data transfer
        int io_reset;   // its necessary to keep it low during data transfer
        int io_update;  // depends os the 23 bit of CFR2
        int prof0;
        int prof1;
        int prof2;
        int osk;        //  osk can be innoprative
        
        cs = 0;        
        io_reset = 0;
        io_update = 0;        
        prof0 = 0;
        prof1 = 0;
        prof2 = 0;        
        osk = 0;   
}

/*void configure_spi(int nbits, int mode, float fsysclk){
    
    SPI         spi(p5, p6, p7);        // MOSI MISO SCLK
    
    spi.format(nbits, mode);
    spi.frequency(fsysclk);    
}*/

void io_update_pulse(float time_us){
        
        int  io_update;         // depends os the 23 bit of CFR2
        
        io_update = 1;
        printf("\t\t---io_update pulse: %.3f us long\n\n", time_us);
        io_update = 0;
}

void write_register(int address, uint64_t data, int data_size){
        
        //SPI         spi(p5, p6, p7);        // MOSI MISO SCLK
        
        int i;
        uint64_t *data_bytes = get_byte(data, data_size);
        
        printf("\t\t---Wrtiting at register 0x%02X...\n",address);    //  address
        printf("\t\t\tdata: 0x");
        for(i=0; i+1 <= data_size/8; i++){
            printf("%02X ",data_bytes[i]);
        }
        free(data_bytes);
        printf("\n\t\t\t\tData written successfully!!\n\n");
        
        io_update_pulse(100);
}
