#include "AD9910.cpp"

// in this example pin's declarations are substituted by ints
// spi. communication is substituted by printf

int main(){
    
    printf("\n---------------------- CONSOLE TEST FOR AD9910 CONTROL ----------------------\n\n");
    
    float fsysclk = 25.0e+6;
    
    STP_write(Prof0, 0.8, 54.0, 22.8e+6, fsysclk);

    printf("----------------------------------------------------------------------------\n\n");
    
    return 0;
            
}
